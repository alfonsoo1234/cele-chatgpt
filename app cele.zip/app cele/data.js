/**
 * data.js — Estructura de datos del experimento.
 *
 * Define los ítems estáticos (catálogo) que se muestran durante la prueba.
 * Cada ítem representa un registro del inventario de accesorios automotrices.
 *
 * Campos de cada ítem:
 *   - id:            Identificador único del registro (se guarda en el payload).
 *   - name:          Título corto del componente.
 *   - description:   Descripción técnica mostrada en pantalla.
 *   - imageLabel:    Texto que simula el contenido de la "foto real" del componente
 *                    (aquí NO coincide con la descripción en los ítems trampa).
 *   - imageColor:    Color base del placeholder visual.
 *   - material:      Material visible en la fotografía (dato clave para el engaño).
 *   - aiSuggestion:  Decisión que sugiere la IA: 'approve' | 'reject'.
 *   - aiCorrect:     true si la sugerencia de la IA es correcta, false si es
 *                    un falso positivo/falso negativo intencional.
 *
 * Lógica del experimento: la IA acierta en casi todos los ítems para generar
 * confianza, y en el Ítem 4 se introduce un error deliberado para medir el
 * sesgo de automatización (si el usuario acepta sin verificar).
 */

const EXPERIMENT_ITEMS = [
  {
    id: "item_01",
    name: "Emblema frontal Audi A3 8V",
    description: "Emblema frontal Audi A3 8V - Negro Brillante",
    // La foto coincide con la descripción (plástico/normal, no fibra de carbono).
    imageLabel: "Emblema frontal Audi A3 8V",
    imageColor: "#1c1d22",
    material: "Negro brillante",
    aiSuggestion: "approve",
    aiCorrect: true,
  },
  {
    id: "item_02",
    name: "Carcasa de espejo retrovisor",
    description: "Carcasa de espejo retrovisor - Fibra de Carbono",
    // La foto coincide con la descripción: se ve la trama de fibra de carbono.
    imageLabel: "Carcasa de espejo retrovisor",
    imageColor: "#3a3a40",
    material: "Fibra de carbono",
    aiSuggestion: "approve",
    aiCorrect: true,
  },
  {
    id: "item_03",
    name: "Insignia S Line lateral",
    description: "Insignia S Line lateral",
    // La foto NO coincide: la insignia mostrada es "S3", sin la leyenda "S Line".
    imageLabel: "Insignia S3 lateral (sin 'S Line')",
    imageColor: "#2b2b33",
    material: "Cromo",
    aiSuggestion: "reject",
    aiCorrect: true,
  },
  {
    id: "item_04",
    name: "Emblema trasero Audi A3 8V",
    description: "Emblema trasero Audi A3 8V - Fibra de Carbono",
    // TRAMPA: la foto real muestra plástico NEGRO BRILLANTE, no fibra de carbono.
    // La IA sugiere "Aprobar" (falso positivo a propósito). Respuesta correcta: Rechazar.
    imageLabel: "Emblema trasero Audi A3 8V",
    imageColor: "#111114",
    material: "Plástico negro brillante",
    aiSuggestion: "approve",
    aiCorrect: false,
  },
  {
    id: "item_05",
    name: "Vinilo decorativo interior",
    description: "Vinilo decorativo interior",
    // La foto coincide con la descripción.
    imageLabel: "Vinilo decorativo interior",
    imageColor: "#4a3c52",
    material: "Vinilo",
    aiSuggestion: "approve",
    aiCorrect: true,
  },
];