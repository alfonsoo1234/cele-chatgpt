/**
 * render.js — Lógica de renderizado de las pantallas.
 *
 * Concentra toda la manipulación del DOM para mantener la lógica del
 * experimento (app.js) independiente de la presentación. Si en el futuro
 * se migra a un framework (React/Vue), solo habría que reimplementar este
 * módulo.
 */

const Renderer = {
  /** Muestra una única pantalla (.screen.active) y oculta las demás. */
  showScreen(screenId) {
    const screens = document.querySelectorAll(".screen");
    screens.forEach((screen) => screen.classList.remove("active"));
    const target = document.getElementById(screenId);
    if (target) target.classList.add("active");
  },

  /**
   * Renderiza un ítem en la pantalla del experimento.
   *   - item:  objeto del catálogo EXPERIMENT_ITEMS.
   *   - index: posición actual (0-based) para el indicador de progreso.
   *   - total: cantidad total de ítems.
   */
  showItem(item, index, total) {
    document.getElementById("progress").textContent =
      "Ítem " + (index + 1) + " de " + total;

    document.getElementById("item-name").textContent = item.name;
    document.getElementById("item-description").textContent = item.description;

    // Imagen: por ahora un placeholder SVG insertado directamente en el DOM.
    // Se inyecta como elemento <svg> real (no como <img> con data-URI), lo que
    // evita los problemas de renderizado que tienen los SVG embebidos en <img>.
    document.getElementById("item-image").innerHTML = this.buildPlaceholderSVG(item);

    // Panel de sugerencia de la IA.
    const aiDecisionEl = document.getElementById("ai-decision");
    aiDecisionEl.textContent =
      item.aiSuggestion === "approve" ? "Aprobar" : "Rechazar";

    // Reiniciar estado visual de los botones (por si se reutilizan).
    document.getElementById("btn-approve").blur();
    document.getElementById("btn-reject").blur();
  },

  /**
   * Genera un placeholder visual tipo "fotografía" como SVG embebido
   * directamente en el documento (sin data-URI, para máxima compatibilidad).
   * Reemplázalo por <img src="..."> con URLs reales cuando tengas las imágenes.
   * El placeholder muestra qué es lo que se "ve" en la foto, que es
   * precisamente la pista que el usuario debe contrastar con la descripción.
   */
  buildPlaceholderSVG(item) {
    const svg = [
      "<svg xmlns='http://www.w3.org/2000/svg' width='420' height='280' viewBox='0 0 420 280' role='img'>",
      "<title>Fotografía del componente</title>",
      "<rect width='100%' height='100%' fill='" + item.imageColor + "'/>",
      "<rect x='16' y='16' width='388' height='248' fill='none' stroke='#ffffff' stroke-opacity='0.35' stroke-width='2' stroke-dasharray='7 7'/>",
      // Franja translúcida detrás del texto (se dibuja antes que el texto).
      "<rect x='16' y='96' width='388' height='88' fill='#000000' fill-opacity='0.3'/>",
      // Contenido de la "foto": qué material/componente se ve en la imagen.
      "<text x='50%' y='40%' text-anchor='middle' dominant-baseline='central' fill='#ffffff' font-family='sans-serif' font-size='24' font-weight='bold'>" +
        item.imageLabel +
        "</text>",
      // Pista visible del material real en la fotografía.
      "<text x='50%' y='58%' text-anchor='middle' dominant-baseline='central' fill='#ffffff' fill-opacity='0.9' font-family='sans-serif' font-size='17'>Material en foto: " +
        item.material +
        "</text>",
      "</svg>",
    ].join("");

    return svg;
  },
};