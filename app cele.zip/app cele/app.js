/**
 * app.js — Orquestación principal del experimento.
 *
 * Conecta los datos (data.js), el temporizador (timer.js) y el renderizado
 * (render.js). Además captura las decisiones de forma "invisible":
 * no hay ninguna indicación en pantalla de que se estén registrando
 * decisiones ni tiempos, para no alterar el comportamiento del participante.
 *
 * El flujo es:
 *   Pantalla de inicio -> Pantalla del experimento (5 ítems) -> Pantalla final.
 *
 * Al completar los ítems se imprime por consola el arreglo de resultados,
 * simulando el payload que posteriormente se enviará a la base de datos
 * en Antigravity.
 */

(function () {
  "use strict";

  // ---------------------------------------------------------------------------
  // Estado interno
  // ---------------------------------------------------------------------------
  const results = []; // Arreglo con la decisión y el tiempo de cada ítem.
  let currentIndex = 0; // Índice del ítem actual (0-based).
  let currentItem = null; // Referencia al ítem que está en pantalla ahora.

  // ---------------------------------------------------------------------------
  // Referencias al DOM (se resuelven una sola vez)
  // ---------------------------------------------------------------------------
  const btnStart = document.getElementById("btn-start");
  const btnApprove = document.getElementById("btn-approve");
  const btnReject = document.getElementById("btn-reject");
  const surveyForm = document.getElementById("survey-form");
  const finalThanks = document.getElementById("final-thanks");

  // ---------------------------------------------------------------------------
  // Flujo principal
  // ---------------------------------------------------------------------------

  /** Inicia el experimento desde la pantalla de bienvenida. */
  function startExperiment() {
    // Limpiar registros de una posible sesión anterior.
    results.length = 0;
    currentIndex = 0;

    Renderer.showScreen("screen-test");
    loadCurrentItem();
  }

  /** Carga y renderiza el ítem actual, e inicia el contador de reacción. */
  function loadCurrentItem() {
    currentItem = EXPERIMENT_ITEMS[currentIndex];
    Renderer.showItem(currentItem, currentIndex, EXPERIMENT_ITEMS.length);

    // INICIO del cronómetro: inmediatamente después de pintar el ítem.
    ReactionTimer.start();
  }

  /**
   * Registra la decisión del usuario y avanza al siguiente ítem.
   *   - decision: 'approve' | 'reject'
   * Detiene el cronómetro en el mismo instante del clic (antes de tocar DOM).
   */
  function handleDecision(decision) {
    // DETENCIÓN del cronómetro: exactamente sobre el evento del clic.
    const reactionTimeMs = ReactionTimer.getElapsedMs();

    results.push({
      itemId: currentItem.id,
      decision: decision,
      reactionTimeMs: reactionTimeMs,
      aiSuggestion: currentItem.aiSuggestion,
      aiAccepted: currentItem.aiSuggestion === decision,
    });

    currentIndex += 1;

    if (currentIndex >= EXPERIMENT_ITEMS.length) {
      finishExperiment();
    } else {
      loadCurrentItem();
    }
  }

  /** Termina la fase de ítems: imprime el payload y muestra la pantalla final. */
  function finishExperiment() {
    // Payload de decisiones y tiempos en milisegundos (simulación de envío).
    console.log("[PAYLOAD] Resumen de decisiones y tiempos (ms):", results);
    Renderer.showScreen("screen-final");
  }

  /** Procesa el formulario Likert y emite el payload completo del estudio. */
  function handleSurveySubmit(event) {
    event.preventDefault();

    const q1 = parseInt(document.querySelector('input[name="q1"]:checked').value, 10);
    const q2 = parseInt(document.querySelector('input[name="q2"]:checked').value, 10);

    const fullPayload = {
      itemDecisions: results,
      survey: {
        trustInAI: q1, // Confianza percibida en las sugerencias de la IA.
        aiHelpedDecisions: q2, // Grado de acuerdo: la IA ayudó a decidir mejor.
      },
      submittedAt: new Date().toISOString(),
      // Cadena de eventos en milisegundos lista para enviar a Antigravity.
    };

    console.log("[PAYLOAD] Payload completo para Antigravity:", fullPayload);

    // Ocultar el formulario y mostrar el agradecimiento final.
    surveyForm.classList.add("hidden");
    finalThanks.classList.remove("hidden");
  }

  // ---------------------------------------------------------------------------
  // Listeners
  // ---------------------------------------------------------------------------
  btnStart.addEventListener("click", startExperiment);
  btnApprove.addEventListener("click", function () {
    handleDecision("approve");
  });
  btnReject.addEventListener("click", function () {
    handleDecision("reject");
  });
  surveyForm.addEventListener("submit", handleSurveySubmit);
})();