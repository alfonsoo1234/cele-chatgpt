/**
 * timer.js — Manejo del temporizador de reacción.
 *
 * El tiempo de reacción es la métrica principal del estudio:
 *   - start(): se invoca justo cuando el ítem se renderiza en pantalla.
 *   - stop():  se invoca exactamente cuando el usuario hace clic en un botón.
 *
 * Se usa performance.now(), que devuelve el tiempo con precisión de
 * milisegundos (incluso fracciones), evitando la poca resolución de
 * Date.now() y cubriendo el retraso del propio renderizado sin penalizar
 * al participante.
 */

const ReactionTimer = {
  _startTime: null,
  _elapsedMs: null,

  /** Inicia la medición. Reasigna el origen del contador. */
  start() {
    this.reset();
    this._startTime = performance.now();
  },

  /** Detiene la medición y guarda el resultado en milisegundos. */
  stop() {
    if (this._startTime === null) {
      throw new Error("ReactionTimer.stop() llamado sin haber iniciado start().");
    }
    this._elapsedMs = performance.now() - this._startTime;
    return this._elapsedMs;
  },

  /** Devuelve el último tiempo medido (redondeado a milisegundos enteros). */
  getElapsedMs() {
    return Math.round(this._elapsedMs);
  },

  /** Limpia el estado para reutilizar el temporizador en el siguiente ítem. */
  reset() {
    this._startTime = null;
    this._elapsedMs = null;
  },
};